from flask import Flask,request,render_template,redirect,url_for,session
import numpy as np
import pandas as pd
import pickle
from flask_mysqldb import MySQL
import MySQLdb.cursors
import re


# loading models
df = pickle.load(open('df.pkl','rb'))
similarity = pickle.load(open('similarity.pkl','rb'))

def recommendation(song):
    idx = df[df['song'] == song].index[0]
    distances = sorted(list(enumerate(similarity[idx])),reverse=False,key=lambda x:x[1])

    songs = []
    for i in distances[1:21]:
        songs.append(df.iloc[i[0]].song)
    return songs

#flask app
app = Flask(__name__)

#database connections
app.secret_key = 'xyzsdfg'

app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'recommendation-system'

mysql = MySQL(app)

#paths
@app.route('/')
def home():
    return render_template('home.html')
@app.route('/log')
def log():
    return render_template('login.html')
@app.route('/login', methods =['POST'])
def login():
    mesage = ''
    if request.method == 'POST' and 'username' in request.form and 'password' in request.form:
        username = request.form['username']
        password = request.form['password']
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM user WHERE name = % s AND password = % s', (username, password, ))
        user = cursor.fetchone()
        if user:
            session['loggedin'] = True
            session['userid'] = user['userid']
            session['name'] = user['name']
            session['email'] = user['email']
            mesage = 'Logged in successfully !'
            return redirect(url_for('user'))
        else:
            mesage = 'Please enter correct username / password !'
    return render_template('login.html', mesage = mesage)
@app.route('/rgstr')
def rgstr():
    return render_template('register.html')
@app.route('/register', methods =['POST'])
def register():
    mesage = ''
    if request.method == 'POST' and 'username' in request.form and 'password' in request.form and 'email' in request.form :
        username = request.form['username']
        password = request.form['password']
        email = request.form['email']
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM user WHERE email = % s', (email, ))
        account = cursor.fetchone()
        if account:
            mesage = 'Account already exists !'
        elif not re.match(r'[^@]+@[^@]+\.[^@]+', email):
            mesage = 'Invalid email address !'
        elif not username or not password or not email:
            mesage = 'Please fill out the form !'
        else:
            cursor.execute('INSERT INTO user VALUES (NULL, % s, % s, % s)', (username, email, password, ))
            mysql.connection.commit()
            mesage = 'You have successfully registered !'
    elif request.method == 'POST':
        mesage = 'Please fill out the form !'
    return render_template('register.html', mesage = mesage)
@app.route('/about')
def about():
    return render_template('about.html')
@app.route('/contact')
def contact():
    return render_template('contact.html')
@app.route('/user')
def user():
    name = session.get('name')
    return render_template('user.html', name=name)
@app.route('/index',methods=['POST'])
def index():
    names = list(df['song'].values)
    return render_template('index.html', name = names)
@app.route('/recom',methods=['POST'])
def mysong():
    user_song = request.form['names']
    songs = recommendation(user_song)

    return render_template('recomend.html', songs=songs)
@app.route('/logout')
def logout():
    session.pop('loggedin', None)
    session.pop('userid', None)
    session.pop('email', None)
    return redirect(url_for('log'))
    
#python
if __name__ == "__main__":
    app.run(debug=True)
